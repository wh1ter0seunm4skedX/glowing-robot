from database_utils import check_database_connection
from table_operations import (
    copy_and_convert_data,
    remove_table,
    list_tables,
    import_sql_file,
    fetch_all_page_titles,
    fetch_page_text_by_id,
    create_view_in_my_wiki,
    copy_view_to_target_db,
    copy_and_convert_data_to_small_pages  # Add this import
)
from text_processing import parse_database_text

def main():
    if not check_database_connection():
        print("Database connection failed. Please check your settings and try again.")
        return None, 'exit'

    user = input("\nEnter your username: ")

    def display_menu():
        print(f"\nUsing Database: target_db")
        print("\nData Manipulation Menu:")
        print("----------------------------------------")
        print("1. Fetch all page titles from `all_pages`")
        print("2. Copy and convert data from `latest_text_view` to `all_pages`")
        print("3. Remove a table from target_db database")
        print("4. List tables in target_db database")
        print("5. Import an SQL file into target_db database")
        print("6. Create or replace `latest_text_view` in `my_wiki`")
        print("7. Copy `latest_text_view` from `my_wiki` to `target_db`")
        print("8. Copy and convert data from `latest_text_temp` to `small_pages`")  # New menu option
        print("9. Exit")
        print("----------------------------------------")

    while True:
        display_menu()
        choice = input("Enter your choice: ")

        if choice == '1':
            titles = fetch_all_page_titles()
            if titles:
                for i, (page_id, title) in enumerate(titles):
                    print(f"{i + 1}. Page ID: {page_id}, Title: {title}")
                page_id = input("Enter the page ID to view its text (or type 'back' to return): ")
                if page_id.lower() != 'back':
                    try:
                        page_id = int(page_id)
                        page_text = fetch_page_text_by_id(page_id)
                        if page_text:
                            cleaned_text = parse_database_text(page_text)
                            print(f"\nText for Page ID {page_id}:\n{cleaned_text}")
                        else:
                            print("No text found for the selected page ID.")
                    except ValueError:
                        print("Invalid input. Please enter a valid page ID.")

        elif choice == '2':
            view_name = "latest_text_view"
            copy_and_convert_data(user, view_name)

        elif choice == '3':
            while True:
                table_name = input("Enter the table name to remove (or type 'back' to return): ")
                if table_name.lower() == 'back':
                    break
                remove_table(user, 'target_db', table_name)
                break

        elif choice == '4':
            list_tables('target_db')

        elif choice == '5':
            while True:
                sql_file_path = input("Enter the path to the SQL file (or type 'back' to return): ")
                if sql_file_path.lower() == 'back':
                    break
                import_sql_file(user, 'target_db', sql_file_path)
                break

        elif choice == '6':
            create_view_in_my_wiki(user)

        elif choice == '7':
            copy_view_to_target_db(user)

        elif choice == '8':  # New option for copying data to small_pages
            copy_and_convert_data_to_small_pages(user)

        elif choice == '9':
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
